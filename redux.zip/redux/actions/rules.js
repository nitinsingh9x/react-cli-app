import uuid from 'uuid';

// ADD_RULE
export const rule = (
  {
    description = '',
    note = '',
    createdAt = 0
  } = {}
) => ({
  type: 'ADD_RULE',
  rule: {
    id: uuid(),
    description,
    note,
    createdAt
  }
});

// REMOVE_RULE
export const removeRule = ({ id } = {}) => ({
  type: 'REMOVE_RULE',
  id
});

// EDIT_RULE
export const editRule = (id, updates) => ({
  type: 'EDIT_RULE',
  id,
  updates
});
