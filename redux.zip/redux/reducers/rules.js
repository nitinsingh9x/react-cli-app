// Rule Reducer

const dataReducerDefaultState = [];

export default (state = dataReducerDefaultState, action) => {
  switch (action.type) {
    case 'ADD_RULE':
      return [
        ...state,
        action.expense
      ];
    case 'REMOVE_RULE':
      return state.filter(({ id }) => id !== action.id);
    case 'EDIT_RULE':
      return state.map((expense) => {
        if (expense.id === action.id) {
          return {
            ...expense,
            ...action.updates
          };
        } else {
          return expense;
        };
      });
    default:
      return state;
  }
};
