import { createStore, combineReducers } from 'redux';
import rulesReducer from '../reducers/rules';

export default () => {
  const store = createStore(
    combineReducers({
      rules: rulesReducer,
    })
  );

  return store;
};
