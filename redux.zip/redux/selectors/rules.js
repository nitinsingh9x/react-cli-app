// Get visible rules

export default (rules, { text, sortBy, startDate, endDate }) => {
  
  return rules;
  // Filter Condition
  // return rules.filter((rule) => {
  //   const startDateMatch = typeof startDate !== 'number' || rule.createdAt >= startDate;
  //   const endDateMatch = typeof endDate !== 'number' || rule.createdAt <= endDate;
  //   const textMatch = rule.description.toLowerCase().includes(text.toLowerCase());

  //   return startDateMatch && endDateMatch && textMatch;
  // });
};
